<!DOCTYPE html>
<html lang="en">
<head>
    <title>ONLINE SHOPING</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <div><h1>ONLINE SHOPING</h1></div>
        <div>HOME</div>
        <div>ABOUT</div>
        <div>GALLERY</div>
        <div><button><h3> LOGIN</h3></button></div>

    </div>
</body>
</html>