<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
      <div>
        <form action="user_login.php" method="post">
        <div>
     u_name:--- <input type="text" name="u_name" placeholder="ENTER YOUR USERNAME" style="margin-left: 70px; ">
    </div>
    <div>password:--- <input type="password" name="password" placeholder="ENTER YOUR PASSWORD"  style="margin-left: 61px;"></div>

    <div><input type="submit" name="submit" value="USER_SUBMIT" ></div>
     <div> <input type="reset" name="reset" value="USER_RESET">

</div>


        </form>
      </div>
</body>
</html>